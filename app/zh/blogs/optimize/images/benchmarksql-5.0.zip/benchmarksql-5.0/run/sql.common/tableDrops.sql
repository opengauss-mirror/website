drop table bmsql_config;

drop table bmsql_new_order;

drop table bmsql_order_line;

drop table bmsql_oorder;

drop table bmsql_history;

drop table bmsql_customer;

drop table bmsql_stock;

drop table bmsql_item;

drop table bmsql_district;

drop table bmsql_warehouse;

drop sequence bmsql_hist_id_seq;

